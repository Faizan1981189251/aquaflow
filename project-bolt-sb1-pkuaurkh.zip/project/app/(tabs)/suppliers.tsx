import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Image,
  TextInput
} from 'react-native';
import { 
  Search,
  Filter,
  MapPin,
  Star,
  Clock,
  Award,
  Truck,
  Shield,
  ThumbsUp,
  Droplet
} from 'lucide-react-native';

export default function SuppliersScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'certified' | 'nearby' | 'premium'>('all');

  const suppliers = [
    {
      id: '1',
      name: 'Pure Waters Co.',
      rating: 4.8,
      reviewCount: 324,
      distance: '0.5 km',
      deliveryTime: '25 min',
      isCertified: true,
      isPremium: true,
      pricePerJar: 25,
      pricePerBottle: 15,
      description: 'Premium quality water with advanced filtration',
      image: 'https://images.pexels.com/photos/416528/pexels-photo-416528.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
      specialties: ['RO Filtered', '7-Stage Purification', 'TDS Tested'],
      availability: 'Available',
    },
    {
      id: '2',
      name: 'Crystal Clear Water',
      rating: 4.6,
      reviewCount: 198,
      distance: '0.8 km',
      deliveryTime: '30 min',
      isCertified: true,
      isPremium: false,
      pricePerJar: 22,
      pricePerBottle: 12,
      description: 'Reliable water delivery service since 2015',
      image: 'https://images.pexels.com/photos/327090/pexels-photo-327090.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
      specialties: ['UV Treated', 'Mineral Rich', 'pH Balanced'],
      availability: 'Available',
    },
    {
      id: '3',
      name: 'AquaPure Solutions',
      rating: 4.9,
      reviewCount: 456,
      distance: '1.2 km',
      deliveryTime: '35 min',
      isCertified: true,
      isPremium: true,
      pricePerJar: 28,
      pricePerBottle: 18,
      description: 'Award-winning water purification technology',
      image: 'https://images.pexels.com/photos/1187032/pexels-photo-1187032.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
      specialties: ['Alkaline Water', 'Ozonated', 'ISO Certified'],
      availability: 'Busy',
    },
    {
      id: '4',
      name: 'Fresh Water Hub',
      rating: 4.4,
      reviewCount: 89,
      distance: '1.5 km',
      deliveryTime: '40 min',
      isCertified: false,
      isPremium: false,
      pricePerJar: 20,
      pricePerBottle: 10,
      description: 'Budget-friendly water delivery options',
      image: 'https://images.pexels.com/photos/327090/pexels-photo-327090.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
      specialties: ['Basic Filtration', 'Local Source'],
      availability: 'Available',
    }
  ];

  const filters = [
    { key: 'all', label: 'All', icon: Droplet },
    { key: 'certified', label: 'Certified', icon: Award },
    { key: 'nearby', label: 'Nearby', icon: MapPin },
    { key: 'premium', label: 'Premium', icon: Shield },
  ];

  const filteredSuppliers = suppliers.filter(supplier => {
    if (activeFilter === 'certified') return supplier.isCertified;
    if (activeFilter === 'nearby') return parseFloat(supplier.distance) <= 1.0;
    if (activeFilter === 'premium') return supplier.isPremium;
    return true;
  }).filter(supplier => 
    supplier.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Water Suppliers</Text>
        <Text style={styles.headerSubtitle}>Find quality water near you</Text>
      </View>

      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <View style={styles.searchBar}>
          <Search color="#64748B" size={20} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search suppliers..."
            placeholderTextColor="#94A3B8"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          <TouchableOpacity style={styles.filterIcon}>
            <Filter color="#0EA5E9" size={20} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Filter Tabs */}
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false} 
        style={styles.filterContainer}
        contentContainerStyle={styles.filterContent}
      >
        {filters.map((filter) => {
          const IconComponent = filter.icon;
          return (
            <TouchableOpacity
              key={filter.key}
              style={[
                styles.filterTab,
                activeFilter === filter.key && styles.activeFilterTab
              ]}
              onPress={() => setActiveFilter(filter.key as any)}
            >
              <IconComponent 
                color={activeFilter === filter.key ? 'white' : '#64748B'} 
                size={16} 
              />
              <Text style={[
                styles.filterTabText,
                activeFilter === filter.key && styles.activeFilterTabText
              ]}>
                {filter.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      {/* Suppliers List */}
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        <View style={styles.content}>
          {filteredSuppliers.map((supplier) => (
            <TouchableOpacity key={supplier.id} style={styles.supplierCard}>
              <Image source={{ uri: supplier.image }} style={styles.supplierImage} />
              
              <View style={styles.supplierContent}>
                <View style={styles.supplierHeader}>
                  <View style={styles.supplierTitleRow}>
                    <Text style={styles.supplierName}>{supplier.name}</Text>
                    <View style={styles.badges}>
                      {supplier.isCertified && (
                        <View style={styles.certifiedBadge}>
                          <Award color="#10B981" size={12} />
                        </View>
                      )}
                      {supplier.isPremium && (
                        <View style={styles.premiumBadge}>
                          <Shield color="#8B5CF6" size={12} />
                        </View>
                      )}
                    </View>
                  </View>
                  
                  <View style={styles.supplierMeta}>
                    <View style={styles.rating}>
                      <Star color="#F59E0B" size={14} fill="#F59E0B" />
                      <Text style={styles.ratingText}>{supplier.rating}</Text>
                      <Text style={styles.reviewCount}>({supplier.reviewCount})</Text>
                    </View>
                    <View style={styles.metaItem}>
                      <MapPin color="#64748B" size={14} />
                      <Text style={styles.metaText}>{supplier.distance}</Text>
                    </View>
                    <View style={styles.metaItem}>
                      <Clock color="#64748B" size={14} />
                      <Text style={styles.metaText}>{supplier.deliveryTime}</Text>
                    </View>
                  </View>
                </View>

                <Text style={styles.description}>{supplier.description}</Text>

                <View style={styles.specialties}>
                  {supplier.specialties.map((specialty, index) => (
                    <View key={index} style={styles.specialtyTag}>
                      <Text style={styles.specialtyText}>{specialty}</Text>
                    </View>
                  ))}
                </View>

                <View style={styles.supplierFooter}>
                  <View style={styles.pricing}>
                    <Text style={styles.price}>₹{supplier.pricePerJar}/jar</Text>
                    <Text style={styles.priceSecondary}>₹{supplier.pricePerBottle}/bottle</Text>
                  </View>
                  
                  <View style={styles.orderSection}>
                    <View style={[
                      styles.availabilityStatus,
                      supplier.availability === 'Available' ? styles.available : styles.busy
                    ]}>
                      <Text style={[
                        styles.availabilityText,
                        supplier.availability === 'Available' ? styles.availableText : styles.busyText
                      ]}>
                        {supplier.availability}
                      </Text>
                    </View>
                    
                    <TouchableOpacity 
                      style={[
                        styles.orderButton,
                        supplier.availability !== 'Available' && styles.disabledButton
                      ]}
                      disabled={supplier.availability !== 'Available'}
                    >
                      <Text style={styles.orderButtonText}>Order Now</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  headerTitle: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1E293B',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  searchContainer: {
    paddingHorizontal: 24,
    paddingVertical: 16,
    backgroundColor: 'white',
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8FAFC',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  searchInput: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1E293B',
  },
  filterIcon: {
    padding: 4,
  },
  filterContainer: {
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  filterContent: {
    paddingHorizontal: 24,
    paddingBottom: 16,
    gap: 12,
  },
  filterTab: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8FAFC',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    gap: 6,
  },
  activeFilterTab: {
    backgroundColor: '#0EA5E9',
  },
  filterTabText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
  },
  activeFilterTabText: {
    color: 'white',
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 24,
  },
  supplierCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    overflow: 'hidden',
  },
  supplierImage: {
    width: '100%',
    height: 140,
  },
  supplierContent: {
    padding: 16,
  },
  supplierHeader: {
    marginBottom: 12,
  },
  supplierTitleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  supplierName: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
    flex: 1,
  },
  badges: {
    flexDirection: 'row',
    gap: 8,
  },
  certifiedBadge: {
    backgroundColor: '#DCFCE7',
    borderRadius: 12,
    padding: 4,
  },
  premiumBadge: {
    backgroundColor: '#EDE9FE',
    borderRadius: 12,
    padding: 4,
  },
  supplierMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  rating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  ratingText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
  },
  reviewCount: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  metaText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  description: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginBottom: 12,
    lineHeight: 20,
  },
  specialties: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 16,
  },
  specialtyTag: {
    backgroundColor: '#EFF6FF',
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  specialtyText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#0EA5E9',
  },
  supplierFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  pricing: {
    flex: 1,
  },
  price: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#1E293B',
  },
  priceSecondary: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  orderSection: {
    alignItems: 'flex-end',
    gap: 8,
  },
  availabilityStatus: {
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  available: {
    backgroundColor: '#DCFCE7',
  },
  busy: {
    backgroundColor: '#FEF3C7',
  },
  availabilityText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
  },
  availableText: {
    color: '#10B981',
  },
  busyText: {
    color: '#F59E0B',
  },
  orderButton: {
    backgroundColor: '#0EA5E9',
    borderRadius: 12,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  disabledButton: {
    backgroundColor: '#94A3B8',
  },
  orderButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
});
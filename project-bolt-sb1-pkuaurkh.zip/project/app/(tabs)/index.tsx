import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Image
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { 
  Search, 
  MapPin, 
  Filter, 
  Star, 
  Clock,
  Truck,
  Award,
  Zap
} from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';

export default function HomeScreen() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <LinearGradient
          colors={['#0EA5E9', '#06B6D4']}
          style={styles.header}
        >
          <View style={styles.headerContent}>
            <View>
              <Text style={styles.greeting}>Good morning, {user?.name?.split(' ')[0]}</Text>
              <View style={styles.locationContainer}>
                <MapPin color="white" size={16} />
                <Text style={styles.location}>123 Main St, City</Text>
              </View>
            </View>
            <TouchableOpacity style={styles.profileButton}>
              <Text style={styles.profileInitial}>
                {user?.name?.charAt(0).toUpperCase()}
              </Text>
            </TouchableOpacity>
          </View>

          {/* Search Bar */}
          <View style={styles.searchContainer}>
            <View style={styles.searchBar}>
              <Search color="#64748B" size={20} />
              <TextInput
                style={styles.searchInput}
                placeholder="Search water suppliers..."
                placeholderTextColor="#94A3B8"
                value={searchQuery}
                onChangeText={setSearchQuery}
              />
              <TouchableOpacity style={styles.filterButton}>
                <Filter color="#0EA5E9" size={20} />
              </TouchableOpacity>
            </View>
          </View>
        </LinearGradient>

        {/* Quick Actions */}
        <View style={styles.quickActions}>
          <TouchableOpacity style={styles.quickActionCard}>
            <View style={styles.quickActionIcon}>
              <Zap color="#F59E0B" size={24} />
            </View>
            <Text style={styles.quickActionTitle}>Quick Order</Text>
            <Text style={styles.quickActionSubtitle}>30 min delivery</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.quickActionCard}>
            <View style={styles.quickActionIcon}>
              <Clock color="#8B5CF6" size={24} />
            </View>
            <Text style={styles.quickActionTitle}>Schedule</Text>
            <Text style={styles.quickActionSubtitle}>Plan ahead</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.quickActionCard}>
            <View style={styles.quickActionIcon}>
              <Award color="#10B981" size={24} />
            </View>
            <Text style={styles.quickActionTitle}>Premium</Text>
            <Text style={styles.quickActionSubtitle}>Best quality</Text>
          </TouchableOpacity>
        </View>

        {/* Featured Suppliers */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Featured Suppliers</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {[1, 2, 3].map((item) => (
              <TouchableOpacity key={item} style={styles.supplierCard}>
                <Image
                  source={{ uri: `https://images.pexels.com/photos/416528/pexels-photo-416528.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop` }}
                  style={styles.supplierImage}
                />
                <View style={styles.supplierInfo}>
                  <View style={styles.supplierHeader}>
                    <Text style={styles.supplierName}>Pure Waters Co.</Text>
                    <View style={styles.certifiedBadge}>
                      <Award color="#10B981" size={12} />
                    </View>
                  </View>
                  <View style={styles.supplierMeta}>
                    <View style={styles.rating}>
                      <Star color="#F59E0B" size={14} fill="#F59E0B" />
                      <Text style={styles.ratingText}>4.8</Text>
                    </View>
                    <View style={styles.delivery}>
                      <Truck color="#64748B" size={14} />
                      <Text style={styles.deliveryText}>25 min</Text>
                    </View>
                  </View>
                  <Text style={styles.supplierPrice}>₹25/jar • ₹15/bottle</Text>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Nearby Suppliers */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Nearby Suppliers</Text>
          {[1, 2, 3, 4].map((item) => (
            <TouchableOpacity key={item} style={styles.nearbySupplierCard}>
              <Image
                source={{ uri: `https://images.pexels.com/photos/327090/pexels-photo-327090.jpeg?auto=compress&cs=tinysrgb&w=80&h=80&fit=crop` }}
                style={styles.nearbySupplierImage}
              />
              <View style={styles.nearbySupplierInfo}>
                <View style={styles.nearbySupplierHeader}>
                  <Text style={styles.nearbySupplierName}>Crystal Clear Water</Text>
                  <View style={styles.certifiedBadge}>
                    <Award color="#10B981" size={12} />
                  </View>
                </View>
                <Text style={styles.nearbySupplierAddress}>0.5 km away</Text>
                <View style={styles.nearbySupplierMeta}>
                  <View style={styles.rating}>
                    <Star color="#F59E0B" size={14} fill="#F59E0B" />
                    <Text style={styles.ratingText}>4.6</Text>
                  </View>
                  <Text style={styles.nearbySupplierPrice}>₹22/jar</Text>
                </View>
              </View>
              <TouchableOpacity style={styles.orderButton}>
                <Text style={styles.orderButtonText}>Order</Text>
              </TouchableOpacity>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    paddingTop: 20,
    paddingBottom: 30,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    marginBottom: 24,
  },
  greeting: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: 'white',
    marginBottom: 4,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  location: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: 'rgba(255, 255, 255, 0.8)',
    marginLeft: 4,
  },
  profileButton: {
    width: 40,
    height: 40,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  profileInitial: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: 'white',
  },
  searchContainer: {
    paddingHorizontal: 24,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  searchInput: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1E293B',
  },
  filterButton: {
    padding: 8,
  },
  quickActions: {
    flexDirection: 'row',
    paddingHorizontal: 24,
    paddingTop: 24,
    gap: 12,
  },
  quickActionCard: {
    flex: 1,
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  quickActionIcon: {
    width: 48,
    height: 48,
    backgroundColor: '#F1F5F9',
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  quickActionTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
    marginBottom: 2,
  },
  quickActionSubtitle: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  section: {
    paddingTop: 32,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1E293B',
    paddingHorizontal: 24,
    marginBottom: 16,
  },
  supplierCard: {
    width: 280,
    backgroundColor: 'white',
    borderRadius: 16,
    marginLeft: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  supplierImage: {
    width: '100%',
    height: 120,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  supplierInfo: {
    padding: 16,
  },
  supplierHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  supplierName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
  },
  certifiedBadge: {
    backgroundColor: '#DCFCE7',
    borderRadius: 12,
    padding: 4,
  },
  supplierMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    marginBottom: 8,
  },
  rating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  ratingText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#1E293B',
  },
  delivery: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  deliveryText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  supplierPrice: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#0EA5E9',
  },
  nearbySupplierCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 16,
    marginHorizontal: 24,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  nearbySupplierImage: {
    width: 60,
    height: 60,
    borderRadius: 12,
  },
  nearbySupplierInfo: {
    flex: 1,
    marginLeft: 12,
  },
  nearbySupplierHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  nearbySupplierName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
  },
  nearbySupplierAddress: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginBottom: 8,
  },
  nearbySupplierMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  nearbySupplierPrice: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#0EA5E9',
  },
  orderButton: {
    backgroundColor: '#0EA5E9',
    borderRadius: 12,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  orderButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
});
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Image
} from 'react-native';
import { 
  Clock, 
  Package, 
  CheckCircle, 
  Truck,
  MapPin,
  Phone,
  Star,
  RefreshCw
} from 'lucide-react-native';

export default function OrdersScreen() {
  const [activeTab, setActiveTab] = useState<'active' | 'history'>('active');

  const activeOrders = [
    {
      id: '1',
      supplier: 'Pure Waters Co.',
      items: '2 Jars (20L)',
      total: '₹50',
      status: 'preparing',
      estimatedTime: '25 min',
      driverName: 'Raj Kumar',
      driverPhone: '+91 98765 43210',
      address: '123 Main St, City',
      image: 'https://images.pexels.com/photos/416528/pexels-photo-416528.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'
    },
    {
      id: '2',
      supplier: 'Crystal Clear Water',
      items: '5 Bottles (1L)',
      total: '₹75',
      status: 'on_way',
      estimatedTime: '10 min',
      driverName: 'Amit Singh',
      driverPhone: '+91 87654 32109',
      address: '123 Main St, City',
      image: 'https://images.pexels.com/photos/327090/pexels-photo-327090.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'
    }
  ];

  const orderHistory = [
    {
      id: '3',
      supplier: 'AquaPure Solutions',
      items: '3 Jars (20L)',
      total: '₹75',
      status: 'delivered',
      date: '2 days ago',
      rating: 4.5,
      image: 'https://images.pexels.com/photos/416528/pexels-photo-416528.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'
    },
    {
      id: '4',
      supplier: 'Fresh Water Hub',
      items: '1 Jar (20L)',
      total: '₹25',
      status: 'delivered',
      date: '1 week ago',
      rating: 5.0,
      image: 'https://images.pexels.com/photos/327090/pexels-photo-327090.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'preparing':
        return <Clock color="#F59E0B" size={20} />;
      case 'on_way':
        return <Truck color="#0EA5E9" size={20} />;
      case 'delivered':
        return <CheckCircle color="#10B981" size={20} />;
      default:
        return <Package color="#64748B" size={20} />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'preparing':
        return 'Preparing Order';
      case 'on_way':
        return 'On the Way';
      case 'delivered':
        return 'Delivered';
      default:
        return 'Unknown';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'preparing':
        return '#F59E0B';
      case 'on_way':
        return '#0EA5E9';
      case 'delivered':
        return '#10B981';
      default:
        return '#64748B';
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>My Orders</Text>
      </View>

      {/* Tab Navigation */}
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'active' && styles.activeTab]}
          onPress={() => setActiveTab('active')}
        >
          <Text style={[styles.tabText, activeTab === 'active' && styles.activeTabText]}>
            Active ({activeOrders.length})
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'history' && styles.activeTab]}
          onPress={() => setActiveTab('history')}
        >
          <Text style={[styles.tabText, activeTab === 'history' && styles.activeTabText]}>
            History
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {activeTab === 'active' ? (
          <View style={styles.content}>
            {activeOrders.length > 0 ? (
              activeOrders.map((order) => (
                <View key={order.id} style={styles.orderCard}>
                  <View style={styles.orderHeader}>
                    <View style={styles.orderHeaderLeft}>
                      <Image source={{ uri: order.image }} style={styles.supplierImage} />
                      <View>
                        <Text style={styles.supplierName}>{order.supplier}</Text>
                        <Text style={styles.orderItems}>{order.items}</Text>
                      </View>
                    </View>
                    <Text style={styles.orderTotal}>{order.total}</Text>
                  </View>

                  <View style={styles.orderStatus}>
                    <View style={styles.statusRow}>
                      {getStatusIcon(order.status)}
                      <Text style={[styles.statusText, { color: getStatusColor(order.status) }]}>
                        {getStatusText(order.status)}
                      </Text>
                      <Text style={styles.estimatedTime}>• {order.estimatedTime}</Text>
                    </View>
                  </View>

                  <View style={styles.driverInfo}>
                    <View style={styles.driverDetails}>
                      <MapPin color="#64748B" size={16} />
                      <Text style={styles.addressText}>{order.address}</Text>
                    </View>
                    <View style={styles.driverContact}>
                      <Text style={styles.driverName}>{order.driverName}</Text>
                      <TouchableOpacity style={styles.callButton}>
                        <Phone color="white" size={16} />
                      </TouchableOpacity>
                    </View>
                  </View>

                  <TouchableOpacity style={styles.trackButton}>
                    <Text style={styles.trackButtonText}>Track Order</Text>
                  </TouchableOpacity>
                </View>
              ))
            ) : (
              <View style={styles.emptyState}>
                <Package color="#94A3B8" size={48} />
                <Text style={styles.emptyTitle}>No Active Orders</Text>
                <Text style={styles.emptySubtitle}>Your active orders will appear here</Text>
              </View>
            )}
          </View>
        ) : (
          <View style={styles.content}>
            {orderHistory.map((order) => (
              <View key={order.id} style={styles.historyCard}>
                <View style={styles.orderHeader}>
                  <View style={styles.orderHeaderLeft}>
                    <Image source={{ uri: order.image }} style={styles.supplierImage} />
                    <View>
                      <Text style={styles.supplierName}>{order.supplier}</Text>
                      <Text style={styles.orderItems}>{order.items}</Text>
                      <Text style={styles.orderDate}>{order.date}</Text>
                    </View>
                  </View>
                  <View style={styles.historyRight}>
                    <Text style={styles.orderTotal}>{order.total}</Text>
                    <View style={styles.rating}>
                      <Star color="#F59E0B" size={16} fill="#F59E0B" />
                      <Text style={styles.ratingText}>{order.rating}</Text>
                    </View>
                  </View>
                </View>

                <View style={styles.historyActions}>
                  <TouchableOpacity style={styles.reorderButton}>
                    <RefreshCw color="#0EA5E9" size={16} />
                    <Text style={styles.reorderButtonText}>Reorder</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.reviewButton}>
                    <Text style={styles.reviewButtonText}>Write Review</Text>
                  </TouchableOpacity>
                </View>
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  headerTitle: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1E293B',
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: 'white',
    marginHorizontal: 24,
    marginTop: 16,
    borderRadius: 12,
    padding: 4,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 8,
  },
  activeTab: {
    backgroundColor: '#0EA5E9',
  },
  tabText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
  },
  activeTabText: {
    color: 'white',
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 24,
  },
  orderCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  orderHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  orderHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  supplierImage: {
    width: 48,
    height: 48,
    borderRadius: 12,
    marginRight: 12,
  },
  supplierName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
    marginBottom: 2,
  },
  orderItems: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  orderTotal: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#1E293B',
  },
  orderStatus: {
    marginBottom: 16,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  statusText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
  },
  estimatedTime: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  driverInfo: {
    backgroundColor: '#F8FAFC',
    borderRadius: 12,
    padding: 12,
    marginBottom: 16,
  },
  driverDetails: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  addressText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginLeft: 8,
  },
  driverContact: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  driverName: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
  },
  callButton: {
    backgroundColor: '#10B981',
    borderRadius: 8,
    padding: 8,
  },
  trackButton: {
    backgroundColor: '#0EA5E9',
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: 'center',
  },
  trackButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
  historyCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  historyRight: {
    alignItems: 'flex-end',
  },
  orderDate: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
    marginTop: 2,
  },
  rating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 4,
  },
  ratingText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#1E293B',
  },
  historyActions: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 16,
  },
  reorderButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#EFF6FF',
    borderRadius: 12,
    paddingVertical: 12,
    gap: 8,
  },
  reorderButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#0EA5E9',
  },
  reviewButton: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#F8FAFC',
    borderRadius: 12,
    paddingVertical: 12,
  },
  reviewButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#64748B',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 48,
  },
  emptyTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    textAlign: 'center',
  },
});
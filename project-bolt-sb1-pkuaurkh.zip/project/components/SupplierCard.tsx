import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { Star, Clock, MapPin, Award } from 'lucide-react-native';

interface Supplier {
  id: string;
  name: string;
  rating: number;
  deliveryTime: string;
  distance: string;
  pricePerJar: number;
  isCertified: boolean;
  image: string;
}

interface SupplierCardProps {
  supplier: Supplier;
  onPress: () => void;
}

export default function SupplierCard({ supplier, onPress }: SupplierCardProps) {
  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <Image source={{ uri: supplier.image }} style={styles.image} />
      
      <View style={styles.content}>
        <View style={styles.header}>
          <Text style={styles.name}>{supplier.name}</Text>
          {supplier.isCertified && (
            <View style={styles.certifiedBadge}>
              <Award color="#10B981" size={12} />
            </View>
          )}
        </View>
        
        <View style={styles.metadata}>
          <View style={styles.metaItem}>
            <Star color="#F59E0B" size={14} fill="#F59E0B" />
            <Text style={styles.metaText}>{supplier.rating}</Text>
          </View>
          
          <View style={styles.metaItem}>
            <Clock color="#64748B" size={14} />
            <Text style={styles.metaText}>{supplier.deliveryTime}</Text>
          </View>
          
          <View style={styles.metaItem}>
            <MapPin color="#64748B" size={14} />
            <Text style={styles.metaText}>{supplier.distance}</Text>
          </View>
        </View>
        
        <Text style={styles.price}>₹{supplier.pricePerJar}/jar</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: 120,
  },
  content: {
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  name: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
    flex: 1,
  },
  certifiedBadge: {
    backgroundColor: '#DCFCE7',
    borderRadius: 12,
    padding: 4,
  },
  metadata: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 8,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  metaText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  price: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#0EA5E9',
  },
});
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { Clock, Package, CheckCircle, Truck } from 'lucide-react-native';

interface Order {
  id: string;
  supplier: string;
  items: string;
  total: string;
  status: 'preparing' | 'on_way' | 'delivered';
  estimatedTime?: string;
  date?: string;
  image: string;
}

interface OrderCardProps {
  order: Order;
  onPress: () => void;
}

export default function OrderCard({ order, onPress }: OrderCardProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'preparing':
        return <Clock color="#F59E0B" size={16} />;
      case 'on_way':
        return <Truck color="#0EA5E9" size={16} />;
      case 'delivered':
        return <CheckCircle color="#10B981" size={16} />;
      default:
        return <Package color="#64748B" size={16} />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'preparing':
        return 'Preparing Order';
      case 'on_way':
        return 'On the Way';
      case 'delivered':
        return 'Delivered';
      default:
        return 'Unknown';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'preparing':
        return '#F59E0B';
      case 'on_way':
        return '#0EA5E9';
      case 'delivered':
        return '#10B981';
      default:
        return '#64748B';
    }
  };

  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Image source={{ uri: order.image }} style={styles.supplierImage} />
          <View>
            <Text style={styles.supplierName}>{order.supplier}</Text>
            <Text style={styles.orderItems}>{order.items}</Text>
            {order.date && (
              <Text style={styles.orderDate}>{order.date}</Text>
            )}
          </View>
        </View>
        <Text style={styles.orderTotal}>{order.total}</Text>
      </View>

      <View style={styles.statusRow}>
        {getStatusIcon(order.status)}
        <Text style={[styles.statusText, { color: getStatusColor(order.status) }]}>
          {getStatusText(order.status)}
        </Text>
        {order.estimatedTime && (
          <Text style={styles.estimatedTime}>• {order.estimatedTime}</Text>
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  supplierImage: {
    width: 48,
    height: 48,
    borderRadius: 12,
    marginRight: 12,
  },
  supplierName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
    marginBottom: 2,
  },
  orderItems: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  orderDate: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
    marginTop: 2,
  },
  orderTotal: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#1E293B',
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  statusText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
  },
  estimatedTime: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
});